package com.project.bootcamp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootcampApplicationTests {

	@Test
	void contextLoads() {
	}

}
